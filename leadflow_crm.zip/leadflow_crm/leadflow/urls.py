"""
LeadFlow CRM - Main URL Configuration
========================================
All URL routes are organized here.
Each app has its own urls.py for clean separation.
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView

urlpatterns = [
    # ─── Admin Panel ──────────────────────────────────────────────────────────
    path('admin/', admin.site.urls),

    # ─── Root Redirect ────────────────────────────────────────────────────────
    # Visiting "/" redirects to login page
    path('', RedirectView.as_view(url='/auth/login/', permanent=False)),

    # ─── Authentication App URLs ──────────────────────────────────────────────
    # Handles: /auth/login/, /auth/register/, /auth/logout/
    path('auth/', include('apps.authentication.urls')),

    # ─── Leads App URLs ───────────────────────────────────────────────────────
    # Handles: /leads/dashboard/, /leads/list/, /leads/add/, etc.
    path('leads/', include('apps.leads.urls')),

    # ─── REST API URLs ────────────────────────────────────────────────────────
    # All API endpoints under /api/v1/
    path('api/v1/', include('apps.leads.api_urls')),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
