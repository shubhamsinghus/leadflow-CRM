"""
LeadFlow CRM - WSGI Configuration
Used by web servers like Gunicorn/Apache in production.
"""
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'leadflow.settings')
application = get_wsgi_application()
