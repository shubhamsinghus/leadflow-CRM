"""
Authentication App - Views
============================
Handles: Login, Register, Logout, Profile

Each view is a class or function that processes HTTP requests
and returns HTML responses.
"""

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile
from .forms import LoginForm, RegisterForm


def login_view(request):
    """
    Handle user login.
    GET  → show login form
    POST → validate credentials and log in
    """
    # If already logged in, go to dashboard
    if request.user.is_authenticated:
        return redirect('leads:dashboard')

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Django's authenticate checks username + password
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {user.username}!')

                # Redirect to 'next' URL if provided (e.g., after session timeout)
                next_url = request.GET.get('next', 'leads:dashboard')
                return redirect(next_url)
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()

    return render(request, 'authentication/login.html', {'form': form})


def register_view(request):
    """
    Handle new user registration.
    Creates both a User and a UserProfile.
    """
    if request.user.is_authenticated:
        return redirect('leads:dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            # Create the Django User
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password1'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
            )

            # Create the linked UserProfile
            UserProfile.objects.create(
                user=user,
                role=form.cleaned_data.get('role', 'employee'),
                phone=form.cleaned_data.get('phone', ''),
            )

            messages.success(request, 'Account created! Please log in.')
            return redirect('authentication:login')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = RegisterForm()

    return render(request, 'authentication/register.html', {'form': form})


def logout_view(request):
    """Log the user out and redirect to login page."""
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('authentication:login')


@login_required
def profile_view(request):
    """View and update user profile."""
    profile = request.user.profile

    if request.method == 'POST':
        # Update basic info
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        request.user.email = request.POST.get('email', '')
        request.user.save()

        profile.phone = request.POST.get('phone', '')
        if 'profile_picture' in request.FILES:
            profile.profile_picture = request.FILES['profile_picture']
        profile.save()

        messages.success(request, 'Profile updated successfully!')
        return redirect('authentication:profile')

    return render(request, 'authentication/profile.html', {'profile': profile})
