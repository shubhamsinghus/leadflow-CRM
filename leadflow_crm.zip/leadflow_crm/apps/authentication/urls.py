"""
Authentication App - URL Patterns
====================================
Maps URLs to view functions.
"""

from django.urls import path
from . import views

app_name = 'authentication'  # Namespace for URL reversal: {% url 'authentication:login' %}

urlpatterns = [
    path('login/',    views.login_view,    name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/',   views.logout_view,   name='logout'),
    path('profile/',  views.profile_view,  name='profile'),
]
