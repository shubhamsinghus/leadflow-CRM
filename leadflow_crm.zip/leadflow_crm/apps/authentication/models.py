"""
Authentication App - Models
============================
Extends Django's built-in User model with a UserProfile
to store role (Admin/Employee) and other info.

OOP Concept: Inheritance - UserProfile extends functionality
via a OneToOne relationship with Django's User model.
"""

from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    """
    Extends the default Django User with additional CRM-specific fields.
    Every User gets exactly one UserProfile (OneToOneField).
    """

    # Role choices — defines who can see/do what
    ROLE_CHOICES = [
        ('admin', 'Admin'),         # Full access: all leads, all users
        ('employee', 'Employee'),   # Limited: only their own leads
    ]

    # Link to the built-in Django User (auto-deleted when User is deleted)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')

    # Role determines dashboard and permissions
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='employee')

    # Optional extra info
    phone = models.CharField(max_length=15, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

    def __str__(self):
        return f"{self.user.username} ({self.role})"

    # ── Helper Properties ──────────────────────────────────────────────────────
    @property
    def is_admin(self):
        """Check if this user has admin role."""
        return self.role == 'admin'

    @property
    def full_name(self):
        """Return full name or username as fallback."""
        return self.user.get_full_name() or self.user.username
