"""
Authentication App - Admin Panel Configuration
Customizes how UserProfile appears in /admin/
"""

from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from .models import UserProfile


class UserProfileInline(admin.StackedInline):
    """Shows UserProfile fields inline inside the User admin page."""
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'


class CustomUserAdmin(UserAdmin):
    """Extends the default User admin to show profile inline."""
    inlines = (UserProfileInline,)
    list_display = ['username', 'email', 'first_name', 'last_name', 'get_role', 'is_active']

    def get_role(self, obj):
        try:
            return obj.profile.role
        except UserProfile.DoesNotExist:
            return 'No Profile'
    get_role.short_description = 'Role'


# Re-register User with our custom admin
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
admin.site.register(UserProfile)

# Customize admin panel branding
admin.site.site_header = "LeadFlow CRM Admin"
admin.site.site_title = "LeadFlow Admin"
admin.site.index_title = "Welcome to LeadFlow CRM"
