"""
Leads App - API Serializers
==============================
Serializers convert Lead model instances to/from JSON.
Think of them as "translators" between Python objects and JSON.
"""

from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Lead, ActivityLog


class UserSerializer(serializers.ModelSerializer):
    """Simplified user info for nested display in Lead API."""
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email']


class LeadSerializer(serializers.ModelSerializer):
    """
    Full Lead serializer for API responses.
    Includes computed fields and nested user info.
    """
    # Read-only computed fields
    status_display   = serializers.CharField(source='get_status_display',   read_only=True)
    source_display   = serializers.CharField(source='get_source_display',   read_only=True)
    priority_display = serializers.CharField(source='get_priority_display', read_only=True)
    assigned_to_info = UserSerializer(source='assigned_to', read_only=True)
    created_by_info  = UserSerializer(source='created_by',  read_only=True)
    is_overdue       = serializers.BooleanField(read_only=True)

    class Meta:
        model  = Lead
        fields = [
            'id', 'name', 'email', 'phone', 'company', 'address',
            'source', 'source_display',
            'status', 'status_display',
            'priority', 'priority_display',
            'budget', 'notes', 'follow_up_date',
            'assigned_to', 'assigned_to_info',
            'created_by', 'created_by_info',
            'is_overdue',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_by', 'created_at', 'updated_at']


class LeadCreateSerializer(serializers.ModelSerializer):
    """
    Simplified serializer for creating/updating leads via API.
    Does not expose nested objects (avoids complexity).
    """
    class Meta:
        model  = Lead
        fields = [
            'name', 'email', 'phone', 'company', 'address',
            'source', 'status', 'priority',
            'budget', 'notes', 'follow_up_date', 'assigned_to',
        ]


class ActivityLogSerializer(serializers.ModelSerializer):
    """Serializer for activity log entries."""
    user_name = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model  = ActivityLog
        fields = ['id', 'lead', 'user', 'user_name', 'action', 'description', 'created_at']
        read_only_fields = ['id', 'created_at']
