"""
Leads App - Views
===================
All views for lead management.

Includes:
  - Dashboard with analytics
  - Lead list with search/filter/pagination
  - Add / Edit / Delete leads
  - Activity log view
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Count
from django.http import JsonResponse
from django.utils import timezone

from .models import Lead, ActivityLog
from .forms import LeadForm


def log_activity(lead, user, action, description):
    """
    Helper function to create activity log entries.
    Called whenever something important happens to a lead.
    """
    ActivityLog.objects.create(
        lead=lead,
        user=user,
        action=action,
        description=description
    )


@login_required
def dashboard_view(request):
    """
    Main dashboard — shows analytics and summary stats.
    Admins see ALL leads; Employees see only THEIR leads.
    """
    user = request.user

    # ── Query Filtering Based on Role ─────────────────────────────────────────
    if hasattr(user, 'profile') and user.profile.is_admin:
        leads_qs = Lead.objects.all()
    else:
        leads_qs = Lead.objects.filter(assigned_to=user)

    # ── Status Counts for Analytics Cards ─────────────────────────────────────
    status_counts = leads_qs.values('status').annotate(count=Count('status'))
    status_dict = {item['status']: item['count'] for item in status_counts}

    # ── Source Counts for Chart ────────────────────────────────────────────────
    source_counts = leads_qs.values('source').annotate(count=Count('source')).order_by('-count')

    # ── Recent Leads (last 5) ──────────────────────────────────────────────────
    recent_leads = leads_qs[:5]

    # ── Recent Activity Logs ───────────────────────────────────────────────────
    if user.profile.is_admin:
        recent_logs = ActivityLog.objects.all()[:10]
    else:
        recent_logs = ActivityLog.objects.filter(user=user)[:10]

    context = {
        'total_leads':     leads_qs.count(),
        'new_leads':       status_dict.get('new', 0),
        'contacted_leads': status_dict.get('contacted', 0),
        'followup_leads':  status_dict.get('follow_up', 0),
        'converted_leads': status_dict.get('converted', 0),
        'lost_leads':      status_dict.get('lost', 0),
        'source_counts':   list(source_counts),
        'recent_leads':    recent_leads,
        'recent_logs':     recent_logs,
    }

    return render(request, 'leads/dashboard.html', context)


@login_required
def lead_list_view(request):
    """
    Show all leads with search, filter, and pagination.
    Supports: ?search=name&status=new&source=instagram&page=2
    """
    user = request.user

    # Base queryset based on role
    if hasattr(user, 'profile') and user.profile.is_admin:
        leads_qs = Lead.objects.select_related('assigned_to', 'created_by').all()
    else:
        leads_qs = Lead.objects.select_related('assigned_to', 'created_by').filter(assigned_to=user)

    # ── Search: name, email, phone, company ───────────────────────────────────
    search_query = request.GET.get('search', '').strip()
    if search_query:
        leads_qs = leads_qs.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(company__icontains=search_query)
        )

    # ── Filter by Status ──────────────────────────────────────────────────────
    status_filter = request.GET.get('status', '')
    if status_filter:
        leads_qs = leads_qs.filter(status=status_filter)

    # ── Filter by Source ──────────────────────────────────────────────────────
    source_filter = request.GET.get('source', '')
    if source_filter:
        leads_qs = leads_qs.filter(source=source_filter)

    # ── Filter by Priority ────────────────────────────────────────────────────
    priority_filter = request.GET.get('priority', '')
    if priority_filter:
        leads_qs = leads_qs.filter(priority=priority_filter)

    # ── Sorting ───────────────────────────────────────────────────────────────
    sort_by = request.GET.get('sort', '-created_at')
    valid_sorts = ['name', '-name', 'created_at', '-created_at', 'status', 'priority']
    if sort_by in valid_sorts:
        leads_qs = leads_qs.order_by(sort_by)

    # ── Pagination: 10 leads per page ─────────────────────────────────────────
    paginator = Paginator(leads_qs, 10)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj':       page_obj,
        'search_query':   search_query,
        'status_filter':  status_filter,
        'source_filter':  source_filter,
        'priority_filter': priority_filter,
        'sort_by':        sort_by,
        'total_count':    leads_qs.count(),
        'status_choices': Lead.STATUS_CHOICES,
        'source_choices': Lead.SOURCE_CHOICES,
    }

    return render(request, 'leads/lead_list.html', context)


@login_required
def lead_detail_view(request, pk):
    """Show full details of a single lead plus its activity log."""
    lead = get_object_or_404(Lead, pk=pk)

    # Employees can only view leads assigned to them
    if not request.user.profile.is_admin and lead.assigned_to != request.user:
        messages.error(request, 'You do not have permission to view this lead.')
        return redirect('leads:lead_list')

    logs = lead.logs.all()[:20]

    return render(request, 'leads/lead_detail.html', {'lead': lead, 'logs': logs})


@login_required
def lead_add_view(request):
    """Add a new lead."""
    if request.method == 'POST':
        form = LeadForm(request.POST, user=request.user)
        if form.is_valid():
            lead = form.save(commit=False)
            lead.created_by = request.user

            # If employee is adding, auto-assign to themselves
            if not request.user.profile.is_admin:
                lead.assigned_to = request.user

            lead.save()

            # Log the activity
            log_activity(lead, request.user, 'created', f'Lead "{lead.name}" was created.')

            messages.success(request, f'Lead "{lead.name}" added successfully!')
            return redirect('leads:lead_list')
        else:
            messages.error(request, 'Please fix the form errors below.')
    else:
        form = LeadForm(user=request.user)

    return render(request, 'leads/lead_form.html', {'form': form, 'title': 'Add New Lead', 'is_edit': False})


@login_required
def lead_edit_view(request, pk):
    """Edit an existing lead."""
    lead = get_object_or_404(Lead, pk=pk)

    # Permission check
    if not request.user.profile.is_admin and lead.assigned_to != request.user:
        messages.error(request, 'You do not have permission to edit this lead.')
        return redirect('leads:lead_list')

    if request.method == 'POST':
        old_status = lead.status
        form = LeadForm(request.POST, instance=lead, user=request.user)
        if form.is_valid():
            updated_lead = form.save()

            # Log status change separately if it changed
            if old_status != updated_lead.status:
                log_activity(
                    updated_lead, request.user, 'status',
                    f'Status changed from "{old_status}" to "{updated_lead.status}".'
                )
            else:
                log_activity(updated_lead, request.user, 'updated', f'Lead "{updated_lead.name}" was updated.')

            messages.success(request, f'Lead "{updated_lead.name}" updated successfully!')
            return redirect('leads:lead_list')
    else:
        form = LeadForm(instance=lead, user=request.user)

    return render(request, 'leads/lead_form.html', {
        'form': form, 'lead': lead, 'title': 'Edit Lead', 'is_edit': True
    })


@login_required
def lead_delete_view(request, pk):
    """Delete a lead (POST only for safety)."""
    lead = get_object_or_404(Lead, pk=pk)

    # Only admins can delete
    if not request.user.profile.is_admin:
        messages.error(request, 'Only admins can delete leads.')
        return redirect('leads:lead_list')

    if request.method == 'POST':
        lead_name = lead.name
        log_activity(None, request.user, 'deleted', f'Lead "{lead_name}" was permanently deleted.')
        lead.delete()
        messages.success(request, f'Lead "{lead_name}" deleted.')
        return redirect('leads:lead_list')

    return render(request, 'leads/lead_confirm_delete.html', {'lead': lead})


@login_required
def activity_log_view(request):
    """Show full activity log. Admins see all; employees see their own."""
    if request.user.profile.is_admin:
        logs = ActivityLog.objects.select_related('user', 'lead').all()
    else:
        logs = ActivityLog.objects.select_related('user', 'lead').filter(user=request.user)

    paginator = Paginator(logs, 20)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    return render(request, 'leads/activity_log.html', {'page_obj': page_obj})


@login_required
def quick_status_update(request, pk):
    """
    AJAX endpoint to update lead status quickly from the list view.
    Returns JSON response.
    """
    if request.method == 'POST':
        lead = get_object_or_404(Lead, pk=pk)
        new_status = request.POST.get('status')

        valid_statuses = [s[0] for s in Lead.STATUS_CHOICES]
        if new_status in valid_statuses:
            old_status = lead.status
            lead.status = new_status
            lead.save()

            log_activity(lead, request.user, 'status',
                         f'Status updated from "{old_status}" to "{new_status}" via quick update.')

            return JsonResponse({'success': True, 'status': new_status,
                                 'badge_color': lead.status_badge_color})

    return JsonResponse({'success': False, 'error': 'Invalid request'}, status=400)
