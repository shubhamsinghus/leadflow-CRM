"""
Leads App - URL Patterns
==========================
All lead management URLs.
"""

from django.urls import path
from . import views

app_name = 'leads'

urlpatterns = [
    # ─── Dashboard ────────────────────────────────────────────────────────────
    path('dashboard/',                  views.dashboard_view,       name='dashboard'),

    # ─── Lead CRUD ────────────────────────────────────────────────────────────
    path('list/',                       views.lead_list_view,       name='lead_list'),
    path('detail/<int:pk>/',            views.lead_detail_view,     name='lead_detail'),
    path('add/',                        views.lead_add_view,        name='lead_add'),
    path('edit/<int:pk>/',              views.lead_edit_view,       name='lead_edit'),
    path('delete/<int:pk>/',            views.lead_delete_view,     name='lead_delete'),

    # ─── Activity Log ─────────────────────────────────────────────────────────
    path('activity-log/',               views.activity_log_view,    name='activity_log'),

    # ─── AJAX Endpoints ───────────────────────────────────────────────────────
    path('quick-status/<int:pk>/',      views.quick_status_update,  name='quick_status'),
]
