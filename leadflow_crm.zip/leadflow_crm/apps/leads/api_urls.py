"""
Leads App - REST API URL Patterns
====================================
All API endpoints under /api/v1/
"""

from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token
from . import api_views

urlpatterns = [
    # ─── Authentication ───────────────────────────────────────────────────────
    # POST /api/v1/token/ with {username, password} → returns auth token
    path('token/',             obtain_auth_token,                    name='api_token'),

    # ─── Leads ────────────────────────────────────────────────────────────────
    path('leads/',             api_views.LeadListCreateAPIView.as_view(),  name='api_leads'),
    path('leads/<int:pk>/',    api_views.LeadDetailAPIView.as_view(),      name='api_lead_detail'),
    path('leads/stats/',       api_views.lead_stats_api,                   name='api_lead_stats'),

    # ─── Activity Logs ────────────────────────────────────────────────────────
    path('activity-logs/',     api_views.ActivityLogListAPIView.as_view(), name='api_activity_logs'),
]
