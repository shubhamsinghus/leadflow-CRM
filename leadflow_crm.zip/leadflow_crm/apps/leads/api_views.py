"""
Leads App - REST API Views
============================
Provides JSON API endpoints for leads.
Can be used by mobile apps, third-party tools, etc.

Authentication: Token-based (pass "Authorization: Token YOUR_TOKEN" header)

Available Endpoints:
  GET    /api/v1/leads/          → List all leads
  POST   /api/v1/leads/          → Create a new lead
  GET    /api/v1/leads/{id}/     → Get one lead
  PUT    /api/v1/leads/{id}/     → Update a lead (full update)
  PATCH  /api/v1/leads/{id}/     → Update a lead (partial)
  DELETE /api/v1/leads/{id}/     → Delete a lead
  GET    /api/v1/leads/stats/    → Dashboard stats
  GET    /api/v1/activity-logs/  → Activity logs
"""

from rest_framework import generics, status, filters
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Count, Q

from .models import Lead, ActivityLog
from .serializers import LeadSerializer, LeadCreateSerializer, ActivityLogSerializer


class LeadListCreateAPIView(generics.ListCreateAPIView):
    """
    GET  → returns list of leads (paginated, supports filtering)
    POST → creates a new lead

    Query Parameters:
      ?search=john           → search by name/email/phone
      ?status=new            → filter by status
      ?source=instagram      → filter by source
      ?ordering=-created_at  → sort results
    """
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, filters.OrderingFilter]
    search_fields      = ['name', 'email', 'phone', 'company']
    ordering_fields    = ['created_at', 'name', 'status', 'priority']
    ordering           = ['-created_at']

    def get_queryset(self):
        """Filter leads based on user role."""
        user = self.request.user
        if hasattr(user, 'profile') and user.profile.is_admin:
            qs = Lead.objects.all()
        else:
            qs = Lead.objects.filter(assigned_to=user)

        # Optional query filters
        status_filter = self.request.query_params.get('status')
        source_filter = self.request.query_params.get('source')
        if status_filter:
            qs = qs.filter(status=status_filter)
        if source_filter:
            qs = qs.filter(source=source_filter)

        return qs

    def get_serializer_class(self):
        """Use different serializers for read vs write."""
        if self.request.method == 'POST':
            return LeadCreateSerializer
        return LeadSerializer

    def perform_create(self, serializer):
        """Set created_by automatically from the logged-in user."""
        lead = serializer.save(created_by=self.request.user)

        # Log the creation
        ActivityLog.objects.create(
            lead=lead, user=self.request.user,
            action='created',
            description=f'Lead "{lead.name}" created via API.'
        )


class LeadDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET    → get one lead by ID
    PUT    → full update
    PATCH  → partial update
    DELETE → delete lead
    """
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'profile') and user.profile.is_admin:
            return Lead.objects.all()
        return Lead.objects.filter(assigned_to=user)

    def get_serializer_class(self):
        if self.request.method in ['PUT', 'PATCH']:
            return LeadCreateSerializer
        return LeadSerializer

    def perform_update(self, serializer):
        lead = serializer.save()
        ActivityLog.objects.create(
            lead=lead, user=self.request.user,
            action='updated',
            description=f'Lead "{lead.name}" updated via API.'
        )

    def perform_destroy(self, instance):
        ActivityLog.objects.create(
            lead=None, user=self.request.user,
            action='deleted',
            description=f'Lead "{instance.name}" deleted via API.'
        )
        instance.delete()


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def lead_stats_api(request):
    """
    Returns dashboard statistics as JSON.
    Useful for mobile dashboards or external integrations.

    Example Response:
    {
      "total": 50,
      "by_status": {"new": 10, "converted": 15, ...},
      "by_source": {"instagram": 12, "facebook": 8, ...}
    }
    """
    user = request.user

    if hasattr(user, 'profile') and user.profile.is_admin:
        qs = Lead.objects.all()
    else:
        qs = Lead.objects.filter(assigned_to=user)

    # Count by status
    status_counts = dict(qs.values_list('status').annotate(count=Count('status')))

    # Count by source
    source_counts = dict(qs.values_list('source').annotate(count=Count('source')))

    return Response({
        'total':     qs.count(),
        'by_status': status_counts,
        'by_source': source_counts,
    })


class ActivityLogListAPIView(generics.ListAPIView):
    """GET → list activity logs."""
    serializer_class   = ActivityLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'profile') and user.profile.is_admin:
            return ActivityLog.objects.all()
        return ActivityLog.objects.filter(user=user)
