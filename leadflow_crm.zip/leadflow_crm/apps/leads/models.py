"""
Leads App - Models
====================
The core of the CRM. Defines how leads are stored in MySQL.

Database Tables Created:
  - leads_lead        → stores all lead information
  - leads_activitylog → stores history/audit trail of changes

OOP Concepts:
  - Classes represent database tables
  - Properties add computed behavior
  - Meta class configures table-level options
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Lead(models.Model):
    """
    Represents a business lead/prospect.
    This is the most important model in the CRM.
    """

    # ── Lead Source (Where did this lead come from?) ───────────────────────────
    SOURCE_CHOICES = [
        ('instagram',   'Instagram'),
        ('facebook',    'Facebook'),
        ('whatsapp',    'WhatsApp'),
        ('google_ads',  'Google Ads'),
        ('referral',    'Referral'),
        ('website',     'Website Form'),
        ('direct_call', 'Direct Call'),
        ('email',       'Email'),
        ('other',       'Other'),
    ]

    # ── Lead Status (Where is this lead in the sales pipeline?) ────────────────
    STATUS_CHOICES = [
        ('new',        'New'),
        ('contacted',  'Contacted'),
        ('follow_up',  'Follow-up'),
        ('converted',  'Converted'),
        ('lost',       'Lost'),
    ]

    # ── Priority ───────────────────────────────────────────────────────────────
    PRIORITY_CHOICES = [
        ('low',    'Low'),
        ('medium', 'Medium'),
        ('high',   'High'),
    ]

    # ─── Core Fields ──────────────────────────────────────────────────────────
    name        = models.CharField(max_length=200)
    email       = models.EmailField(blank=True, null=True)
    phone       = models.CharField(max_length=20)
    company     = models.CharField(max_length=200, blank=True, null=True)
    address     = models.TextField(blank=True, null=True)

    # ─── CRM Fields ───────────────────────────────────────────────────────────
    source      = models.CharField(max_length=50,  choices=SOURCE_CHOICES, default='other')
    status      = models.CharField(max_length=50,  choices=STATUS_CHOICES, default='new')
    priority    = models.CharField(max_length=10,  choices=PRIORITY_CHOICES, default='medium')
    notes       = models.TextField(blank=True, null=True)
    budget      = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)

    # ─── Relationships ────────────────────────────────────────────────────────
    # assigned_to: which employee is responsible for this lead
    assigned_to = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='assigned_leads'
    )
    # created_by: who originally added this lead
    created_by  = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_leads'
    )

    # ─── Timestamps ───────────────────────────────────────────────────────────
    follow_up_date = models.DateField(blank=True, null=True)
    created_at     = models.DateTimeField(auto_now_add=True)  # Set once on creation
    updated_at     = models.DateTimeField(auto_now=True)       # Updated on every save

    class Meta:
        ordering = ['-created_at']  # Newest leads first
        verbose_name = 'Lead'
        verbose_name_plural = 'Leads'

    def __str__(self):
        return f"{self.name} ({self.get_status_display()})"

    # ── Helper Properties ──────────────────────────────────────────────────────
    @property
    def status_badge_color(self):
        """Returns Bootstrap badge color based on status."""
        colors = {
            'new':       'primary',
            'contacted': 'info',
            'follow_up': 'warning',
            'converted': 'success',
            'lost':      'danger',
        }
        return colors.get(self.status, 'secondary')

    @property
    def priority_badge_color(self):
        """Returns Bootstrap badge color based on priority."""
        colors = {'low': 'success', 'medium': 'warning', 'high': 'danger'}
        return colors.get(self.priority, 'secondary')

    @property
    def is_overdue(self):
        """Check if follow-up date has passed."""
        if self.follow_up_date:
            return self.follow_up_date < timezone.now().date() and self.status not in ['converted', 'lost']
        return False


class ActivityLog(models.Model):
    """
    Audit trail — records every important action taken on a lead.
    Answers: "Who did what, when?"
    """

    ACTION_CHOICES = [
        ('created',    'Lead Created'),
        ('updated',    'Lead Updated'),
        ('status',     'Status Changed'),
        ('deleted',    'Lead Deleted'),
        ('assigned',   'Lead Assigned'),
        ('note_added', 'Note Added'),
    ]

    lead        = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name='logs', null=True, blank=True)
    user        = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action      = models.CharField(max_length=50, choices=ACTION_CHOICES)
    description = models.TextField()  # Human-readable description of what changed
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Activity Log'
        verbose_name_plural = 'Activity Logs'

    def __str__(self):
        return f"{self.user} - {self.action} on {self.lead} at {self.created_at}"
