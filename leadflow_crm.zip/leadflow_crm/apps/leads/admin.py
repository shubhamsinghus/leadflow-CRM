"""
Leads App - Admin Panel Configuration
"""

from django.contrib import admin
from .models import Lead, ActivityLog


@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display    = ['name', 'phone', 'source', 'status', 'priority', 'assigned_to', 'created_at']
    list_filter     = ['status', 'source', 'priority', 'created_at']
    search_fields   = ['name', 'email', 'phone', 'company']
    list_editable   = ['status', 'priority']
    date_hierarchy  = 'created_at'
    ordering        = ['-created_at']

    fieldsets = (
        ('Contact Info',  {'fields': ('name', 'email', 'phone', 'company', 'address')}),
        ('CRM Details',   {'fields': ('source', 'status', 'priority', 'budget', 'notes', 'follow_up_date')}),
        ('Assignment',    {'fields': ('assigned_to', 'created_by')}),
    )

    readonly_fields = ['created_at', 'updated_at']


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display  = ['user', 'action', 'lead', 'created_at']
    list_filter   = ['action', 'created_at']
    search_fields = ['description', 'user__username']
    readonly_fields = ['created_at']
