"""
Leads App - Forms
==================
LeadForm handles adding and editing leads with validation.
"""

from django import forms
from django.contrib.auth.models import User
from .models import Lead


class LeadForm(forms.ModelForm):
    """
    ModelForm automatically creates fields from the Lead model.
    We only customize widgets (appearance) and add extra validation.
    """

    class Meta:
        model = Lead
        fields = [
            'name', 'email', 'phone', 'company', 'address',
            'source', 'status', 'priority', 'budget',
            'assigned_to', 'notes', 'follow_up_date',
        ]
        widgets = {
            'name':           forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'email':          forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email Address'}),
            'phone':          forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone Number'}),
            'company':        forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Company Name'}),
            'address':        forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Address'}),
            'source':         forms.Select(attrs={'class': 'form-select'}),
            'status':         forms.Select(attrs={'class': 'form-select'}),
            'priority':       forms.Select(attrs={'class': 'form-select'}),
            'budget':         forms.NumberInput(attrs={'class': 'form-control', 'placeholder': '0.00'}),
            'assigned_to':    forms.Select(attrs={'class': 'form-select'}),
            'notes':          forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Notes...'}),
            'follow_up_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        # Accept `user` kwarg to customize form based on role
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        # Only admins can assign leads to other users
        if self.user and hasattr(self.user, 'profile'):
            if not self.user.profile.is_admin:
                self.fields['assigned_to'].widget = forms.HiddenInput()
            else:
                # Show only active users in dropdown
                self.fields['assigned_to'].queryset = User.objects.filter(is_active=True)
                self.fields['assigned_to'].empty_label = "-- Assign to Employee --"

    def clean_phone(self):
        """Basic phone number validation."""
        phone = self.cleaned_data.get('phone', '')
        # Remove spaces and dashes for validation
        cleaned = phone.replace(' ', '').replace('-', '').replace('+', '')
        if cleaned and not cleaned.isdigit():
            raise forms.ValidationError('Phone number should contain only digits.')
        return phone
