/*
  LeadFlow CRM - Main JavaScript
  =================================
  Handles: sidebar toggle, AJAX status updates, form enhancements
*/

document.addEventListener('DOMContentLoaded', function () {

  // ── Sidebar Toggle ───────────────────────────────────────────────────────────
  const toggleBtn = document.getElementById('sidebarToggle');
  const wrapper   = document.getElementById('wrapper');

  if (toggleBtn && wrapper) {
    toggleBtn.addEventListener('click', function () {
      // On mobile: slide in/out
      if (window.innerWidth <= 768) {
        document.querySelector('.sidebar-nav').classList.toggle('open');
      } else {
        // On desktop: collapse/expand
        wrapper.classList.toggle('sidebar-collapsed');
        localStorage.setItem('sidebarCollapsed', wrapper.classList.contains('sidebar-collapsed'));
      }
    });

    // Restore sidebar state from localStorage
    if (localStorage.getItem('sidebarCollapsed') === 'true') {
      wrapper.classList.add('sidebar-collapsed');
    }
  }

  // ── Quick Status Update (AJAX) ───────────────────────────────────────────────
  // Each status dropdown in the lead list can update status without page reload
  document.querySelectorAll('.status-quick-update').forEach(function (select) {
    select.addEventListener('change', function () {
      const leadId   = this.dataset.leadId;
      const newStatus = this.value;

      // Get CSRF token from cookie
      const csrfToken = getCookie('csrftoken');

      fetch(`/leads/quick-status/${leadId}/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-CSRFToken': csrfToken,
        },
        body: `status=${newStatus}`
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showToast('Status updated successfully!', 'success');
        } else {
          showToast('Failed to update status.', 'danger');
        }
      })
      .catch(() => showToast('Network error.', 'danger'));
    });
  });

  // ── Toast Notification ────────────────────────────────────────────────────────
  window.showToast = function (message, type = 'info') {
    const container = getOrCreateToastContainer();
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show shadow`;
    toast.style.cssText = 'min-width:260px; margin-bottom:8px;';
    toast.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    container.appendChild(toast);

    // Auto-remove after 3 seconds
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  };

  function getOrCreateToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.style.cssText = 'position:fixed; top:20px; right:20px; z-index:9999;';
      document.body.appendChild(container);
    }
    return container;
  }

  // ── CSRF Cookie Helper ────────────────────────────────────────────────────────
  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith(name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }

  // ── Auto-dismiss Alerts ───────────────────────────────────────────────────────
  document.querySelectorAll('.alert:not(.alert-permanent)').forEach(function (alert) {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      bsAlert.close();
    }, 4000);
  });

  // ── Form Validation Styling ───────────────────────────────────────────────────
  // Add Bootstrap's "was-validated" class on submit for custom validation styles
  document.querySelectorAll('form[novalidate]').forEach(function (form) {
    form.addEventListener('submit', function () {
      form.classList.add('was-validated');
    });
  });

});
